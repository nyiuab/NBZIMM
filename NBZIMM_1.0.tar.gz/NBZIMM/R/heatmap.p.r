

heatmap.p <- function(p, threshold = c(0.001, 0.01, 0.05), col = c("red", "blue", "lightblue", "grey"), 
                      show.allRow = TRUE, show.allCol = TRUE, cexRow = 0.8, cexCol = 0.8, margins = c(5, 5),
                      main = NULL, xlab = NULL, ylab = NULL)
{
  p <- as.matrix(p)
  if (is.null(rownames(p))) {
    rownames(p) <- paste("row", 1:NROW(p), sep = "")
    warning("rownames of p are not given !")
  }
  if (is.null(colnames(p))) {
    colnames(p) <- paste("row", 1:NCOL(p), sep = "")
    warning("colnames of p are not given !")
  }
  threshold <- sort(threshold)
  myBreaks <- c(0, threshold, 1)
  if (length(col) != length(threshold)+1 ) stop("Number of colors should equal number of breaks")
  myCol <- col
  labRow <- rownames(p)
  labCol <- colnames(p)
  if (!show.allRow)
  {
    rmin <- apply(p, 1, min)
    labRow <- ifelse(rmin < max(threshold), labRow, "")
  }
  if (!show.allCol)
  {
    cmin <- apply(p, 2, min)
    labCol <- ifelse(cmin < max(threshold), labCol, "")
  }
  
  heatmap( p,
          
          Rowv = NA, Colv = NA, scale = "none", 
           
          cexRow = cexRow, cexCol = cexCol,
          margins = margins,     
          main = main, xlab = xlab, ylab = ylab,
          labRow = labRow, labCol = labCol,
          
          col = myCol,            
          breaks = myBreaks )    

}
