
heat.p <- function(df, p.breaks = c(0.001, 0.01, 0.05), 
                   colors = c("darkblue", "blue", "lightblue", "grey"),
                   filter.res = FALSE, filter.var = FALSE,
                   x.size, y.size, symbol.size)
{
  require(ggplot2)
  df = as.data.frame(df)
  if (!"responses" %in% names(df) | !"variables" %in% names(df) |
      !"pvalue" %in% names(df) | !"Estimate" %in% names(df)) 
    stop("df should include 'responses', 'variables', and 'pvalue'") 
  if (length(colors) != length(p.breaks) + 1) 
      stop("number of colors does not equal p value intervals")
  df = df[df[, "variables"] != "(Intercept)", ]
  
  br = c(0, p.breaks, 1)
  br = unique(sort(br))
  df$p_value = cut(df$pvalue, br)
  
  if (filter.res){
    keep.res = as.character(unique(df[df[, "pvalue"] < br[length(br)-1], "responses"]))
    df = df[df[["responses"]]%in%keep.res, ]
  }
  if (filter.var){
    keep.var = as.character(unique(df[df[, "pvalue"] < br[length(br)-1], "variables"]))
    df = df[df[["variables"]]%in%keep.var, ]
  }
  if (missing(x.size)) x.size <- NULL
  if (missing(y.size)) y.size <- NULL
  
  p = ggplot(df, aes(variables, responses)) 
  p = p + xlab("") + ylab("")
  p = p + geom_tile(aes(fill = p_value)) 
  p = p + scale_fill_manual(values = colors)
  p = p + theme(axis.text.x = element_text(angle=90, vjust=0.5, hjust=1, size=x.size))
  p = p + theme(axis.text.y = element_text(size=y.size))
  p = p + theme(legend.justification="top")
  
  df.sub = df[df[,"Estimate"]>0 & df[,"pvalue"]<br[length(br)-1], ]
  if (missing(symbol.size))
    p = p + geom_text(data = df.sub, aes(variables, responses, label = "+"), 
                      col = "white")
  else
    p = p + geom_text(data = df.sub, aes(variables, responses, label = "+"), 
                      col = "white", size = symbol.size)
  
  p
}
