

get.fixed <- function(object, part=c("dist", "zero"), vr.name, sort.p=FALSE)
{
  part <- part[1]
  if (class(object)[1] != "mms") stop("only for object from 'mms'")  
  if (!(class(object)[2] %in% c("zinb", "zig"))) part <- "dist"
  fit <- object$fit
  res <- object$responses
  var <- object$variables
  if (!vr.name %in% c(res, unlist(var))) stop("wrong name given")
  if (vr.name %in% res) 
    out <- lapply(fit, fixed)[[vr.name]][[part]]
  else
    out <- sapply(fixed(object)[[part]], function(x){x[vr.name, ]} )
  
  out <- out[rownames(out)!="(Intercept)", ]
  if (sort.p) out <- out[names(sort(out[, "pvalue"])), ]
  
  out
}


